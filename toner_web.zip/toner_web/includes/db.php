<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toner";
$conn = "";

try{
    $conn = mysqli_connect($servername, $username, $password, $dbname,);
}
catch(mysqli_sql_exception){
    echo "Hiba az adatbázis kapcsolatban!";
}


$sql = "SELECT * FROM printer";
$result = mysqli_query($conn, $sql);
?>



