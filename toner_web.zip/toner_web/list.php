<?php
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $vonalkod = $_POST['vonalkod'];
    
    if (isset($_POST['order'])) {
        
        $query = "UPDATE printer SET rendeles = 1 WHERE vonalkod = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $vonalkod);
        $stmt->execute();
    } elseif (isset($_POST['status'])) {
        $status = $_POST['status'];
        
        if ($status == 'megjott') {
            $query = "UPDATE printer SET megjott_datum = NOW(), rendeles = 0 WHERE vonalkod = ?";
        } elseif ($status == 'rendelve') {
            $query = "UPDATE printer SET rendeles = 1 WHERE vonalkod = ?";
        } else {
            $query = "UPDATE printer SET rendeles = 0 WHERE vonalkod = ?";
        }
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $vonalkod);
        $stmt->execute();
    }
    
    
    header("Location: list.php");
    exit();
}

?>

<!doctype html>
<html lang="en" data-bs-theme="light">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Toner</title>
    <link href="bootstrap.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <link href="./bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

</head>



<body>
       

    <div class="root">
        <div class="offcanvas-xl offcanvas-start" tabindex="-1" id="offcanvas1" aria-labelledby="offcanvasLabel">
            <div class="offcanvas-body sidebar fs-6">
                <div class="sidebar-holder">
                    <div class="sidebar-header">
                        <span class="fs-5 fw-semibold">Docket</span>
                            <button type="button" class="btn-close d-xl-none ms-5" data-bs-dismiss="offcanvas" aria-label="Close" data-bs-target="#offcanvas1"></button>
                    </div>
                    <div class="sidebar-body">
                        <div class="sidebar-items-holder">
                            <div class="sidebar-items">
                                <ul class="nav nav-pills flex-column mb-auto">
                                    <li class="nav-item">
                                        <a href="" class="nav-link active">
                                            <i class="bi bi-house me-2 h6 mb-0 ms-3"><a href="list.php">Nyomtató Lista</a></i>
                                        
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="" class="nav-link">
                                            <i class="bi bi-house me-2 h6 mb-0"></i>
                                            Kezdőlap
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="" class="nav-link">
                                            <i class="bi bi-house me-2 h6 mb-0"></i>
                                            Kezdőlap
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="" class="nav-link">
                                            <i class="bi bi-house me-2 h6 mb-0"></i>
                                            Kezdőlap
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="" class="nav-link">
                                            <i class="bi bi-house me-2 h6 mb-0"></i>
                                            Kezdőlap
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="" class="nav-link">
                                            <i class="bi bi-house me-2 h6 mb-0"></i>
                                            Kezdőlap
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="" class="nav-link">
                                            <i class="bi bi-house me-2 h6 mb-0"></i>
                                            Kezdőlap
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="" class="nav-link">
                                            <i class="bi bi-house me-2 h6 mb-0"></i>
                                            Kezdőlap
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="" class="nav-link">
                                            <i class="bi bi-house me-2 h6 mb-0"></i>
                                            Kezdőlap
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="" class="nav-link">
                                            <i class="bi bi-house me-2 h6 mb-0"></i>
                                            Kezdőlap
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    
                           

                        <div class="sidebar-user">
                            <div class="dropdown">
                                <a href="#"
                                    class="d-flex align-items-center text-decoration-none dropdown-toggle rounded"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <div class="avatar me-2">
                                        <i class="bi bi-person h4 m-0 text-body-bg"></i>
                                    </div>
                                    <div class="fw-semibold">Németh István</div>
                                </a>
                                <ul class="dropdown-menu text-small shadow">
                                    <li><a class="dropdown-item" href="#">New project...</a></li>
                                    <li><a class="dropdown-item" href="#">Settings</a></li>
                                    <li><a class="dropdown-item" href="#">Profile</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Kijelentkezés</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <<div class="col-md-10 p-4 table-all">
            <div class="container shadow-lg rounded">
                <table class="table table-hover table-striped table-bordered text-center">
                    <thead class="thead-dark sticky-top bg-primary text-white">
                        <tr>
                            <th>Vonalkod</th>
                            <th>Gyáriszam</th>
                            <th>Tipus</th>
                            <th>Toner</th>
                            <th>TŰSZ gépkod</th>
                            <th>Toner állapota</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                    <?php
                        foreach($result as $row){
                        echo "<tr>";
                        echo "<td>".$row['vonalkod']."</td>";
                        echo "<td>".$row['gyariszam']."</td>";
                        echo "<td>".$row['tipus']."</td>";
                        echo "<td>".$row['toner']."</td>";
                        echo "<td>".$row['tusz_gepkod']."</td>";
                        
                        if($row['rendeles'] == 1) {
                           
                            echo "<td>
                                    <form method='POST' action=''>
                                        <input type='hidden' name='vonalkod' value='" . $row['vonalkod'] . "'>
                                        <select name='status' class='form-select form-select-sm' onchange='this.form.submit()'>
                                            <option value='rendelve' " . ($row['rendeles'] == 1 ? 'selected' : '') . ">📦 Rendelve</option>
                                            <option value='megjott' " . ($row['rendeles'] == 2 ? 'selected' : '') . ">📦 Megjött</option>
                                        </select>
                                    </form>
                                  </td>";
                        } else {
                            
                            echo "<td>
                                    <form method='POST' action=''>
                                        <input type='hidden' name='vonalkod' value='" . $row['vonalkod'] . "'>
                                        <select name='status' class='form-select form-select-sm' onchange='this.form.submit()'>
                                            <option  value='rendeles' " . ($row['rendeles'] == 0 ? 'selected' : '') . ">📦 Rendelés</option>
                                            <option  value='rendelve' " . ($row['rendeles'] == 1 ? 'selected' : '') . ">📦 Rendelve</option>
                                        </select>
                                    </form>
                                  </td>";
                        }  
                    }
                    ?>
                        
                    </tr>
                       
                     
                    </tbody>
                </table>
            </div>
        </div>



        <div class="content">
            <button class="navbar-toggler border rounded d-xl-none p-1 m-2" type="button" data-bs-toggle="offcanvas"
                data-bs-target="#offcanvas1" aria-controls="bdSidebar" aria-label="Toggle docs navigation">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="bi" fill="currentColor"
                    viewBox="0 0 16 16">
                    <path fill-rule="evenodd"
                        d="M2.5 11.5A.5.5 0 0 1 3 11h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 7h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 3h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z">
                    </path>
                </svg>
            </button>
        </div>
    </div>

    <script src="./js/bootstrap.bundle.js"></script>
    
    
</body>

</html>


